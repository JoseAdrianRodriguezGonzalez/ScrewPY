
from screw.screw import Screw

S=Screw([1,2,3],[4,3,-2])
print(S.getV())