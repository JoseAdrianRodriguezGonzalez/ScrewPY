class Screw:
    def __init__(self,w,v):
        self.w=w
        self.v=v
    def getW(self):
        return self.w
    def getV(self):
        return self.v
    